 <?php 

    $sql2 = $koneksi->query("select * from tb_profile ");

    $data1 = $sql2->fetch_assoc();

 ?>

 <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
<div class="user-panel">
  <div>
  <img style="margin-left:30px" src="images/<?php echo $data1['foto'] ?>" width="140" height="120" >
      <h5 style="color:white; font-size: 16px; text-align: center; "><?php echo $data1['nama_sekolah'] ?></h5>
      
  </div>
  <div class="pull-left info">


  </div>
</div>
<!-- search form -->
<!-- /.search form -->
<!-- sidebar menu: : style can be found in sidebar.less -->


<?php
  switch ($_GET['page']) {
    
    case 'pengguna':
      
      $aktifAdmin='active';
      break;


      case 'kas':
      
      $kas='active';
      break;

      case 'profile':
      
      $aktifprofile='active';
      break;
      

   

    case 'kas':
     
      $aktifB='active';
      $aktifB2='active';
      break;

     

      case 'laporan_kas':
     
      $aktifC='active';
      $aktifC01='active';
      break;

     
   
    //menu home
    default:
      
      $aktifHome='active';
  }
  ?>



<ul class="sidebar-menu" data-widget="tree">
  <li class="header">MAIN NAVIGATION</li>
            
            <li class="<?php echo $aktifHome; ?>"><a href="index.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <?php  if ($_SESSION['admin']){ ?>

             <li class="<?php echo $aktifprofile; ?>"><a href="?page=profile"><i class="fa fa-gear"></i> Setting Profile Sekolah</a></li>
            
        

            <li class="<?php echo $aktifAdmin; ?>"><a href="?page=pengguna"><i class="fa fa-users"></i> Pengguna</a></li>
  <?php } ?>

               
             <li class="<?php echo $kas; ?>"><a href="?page=kas"><i class="fa fa-money"></i>  Kas Masuk dan Keluar</a></li>
           

           

          

        

                  <li class="<?php echo $aktifC01; ?>"><a href="?page=laporan_kas"><i class="fa fa-print"></i> Laporan Kas Masuk dan Keluar</a></li>
            
          


  

 

 

       
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>

  <!-- =============================================== -->

  <!-- Content Wrapper. Contains page content -->
 
