<?php 


		$page = $_GET['page'];
		$aksi = $_GET['aksi'];


		if ($page == "ubah_p") {
	      if ($aksi == "") {
	      include "ubah_password.php";
	      }
	    }

		if ($page == "profile") {
			if ($aksi == "") {
				include "page/profile/profile.php";

			 }
	
	
		}


		

		if ($page == "laporan_kas") {
			if ($aksi == "") {
				include "page/laporan/laporan_kas.php";

			 }
	
	
		}

		









		if ($page == "pengguna") {
			if ($aksi == "") {
				include "page/pengguna/pengguna.php";
			}

			if ($aksi == "tambah") {
				include "page/pengguna/tambah.php";
			}

			if ($aksi == "ubah") {
				include "page/pengguna/ubah.php";
			}

			if ($aksi == "hapus") {
				include "page/pengguna/hapus.php";
			}
		}


		if ($page == "kas") {
			if ($aksi == "") {
				include "page/kas/kas.php";
			}

		}	
	



		if ($page == "") {
			include "home.php";
		}



 ?>