<?php 
	error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
		include "../../include/koneksi.php";
	$tgl_awal = $_POST['tgl_awal'];
	$tgl_akhir = $_POST['tgl_akhir'];

    date_default_timezone_set('Asia/Jakarta');
$tanggal =  date('d-m-Y H:i:s');

	  $satu_hari        = mktime(0,0,0,date("n"),date("j"),date("Y"));
       
          function tglIndonesia2($str){
             $tr   = trim($str);
             $str    = str_replace(array('Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'), array('Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jum\'at', 'Sabtu', 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'), $tr);
             return $str;
         }



 ?>





<style type="text/css">

	.tabel{border-collapse: collapse;}
	.tabel th{padding: 2px 3px; background-color:  #cccccc;  }
	.tabel td{padding: 2px 3px;     }
</style>
<script>
	

			window.print();
			window.onfocus=function() {window.close();}
				
	

</script>
</head>

<body onload="window.print()">
<?php 

    $sql = $koneksi->query("select * from tb_profile ");

    $data1 = $sql->fetch_assoc();

 ?>

 <div style="font-size: 10px;"><?php echo $tanggal; ?></div>
<table width="100%" >
  <tr>
   
    <td width="10"  align="center"><img src="../../images/<?php echo $data1['foto']; ?>" width="80" height="85" /></td>
  </tr>
</table>
<hr>




<table width="100%" >
  <tr>
    <td width="0">&nbsp;</td>
    <td colspan="6"><div align="center"><strong>Laporan  Kas Masuk dan Keluar <br> Tanggal <?php echo  tglIndonesia2(date('d F Y', strtotime($tgl_awal))) ?> - Tanggal <?php echo  tglIndonesia2(date('d F Y', strtotime($tgl_akhir))) ?> </strong></div></td>
  </tr>
  
  
</table><br>


  

	
</table>



<table class="tabel" border="1" width="100%">

  <thead>
    <tr>
      			  <th>No</th>
                  <th>Tanggal</th>
                  <th>Keterangan</th>
                  <th>Kas Masuk</th>
                  <th>Kas Keluar</th>
                  
                  
    </tr>
  </thead>
    <tbody>
  
                     <?php 

                      $no = 1;

                    $sql = $koneksi->query("select * from tb_kas where tgl_kas between '$tgl_awal' and '$tgl_akhir' order by id_kas desc");

                			while ($data = $sql->fetch_assoc()) {

                      $status =$data['status'];

                      $t_masuk = $data['penerimaan'];
                      $t_Keluar = $data['pengeluaran'];

                      $total_masuk = $total_masuk+$t_masuk;
                      $total_keluar = $total_keluar+$t_Keluar;
                      $saldo = $total_masuk-$total_keluar;

                   
                        
                      
                   ?>


                <tr>
                  <td><?php echo $no++; ?></td>
                  <td><?php echo date('d/m/Y', strtotime($data['tgl_kas'])) ?></td>
                  <td><?php echo $data['keterangan'] ?></td>
                  <td align="right"><?php echo number_format($data['penerimaan'],0,",",".") ?></td>
                  <td align="right"><?php echo number_format($data['pengeluaran'],0,",",".") ?></td>
                 

                 </tr> 



                 <?php


                  } 

                  ?>

                  <tr>
           	
           	<td colspan="3" style="text-align: center; font-weight: bold; font-size: 16px">Total</td>
           	<td align="right"><?php echo number_format($total_masuk,0,",",".") ?></td>
           	<td align="right"><?php echo number_format($total_keluar,0,",",".") ?></td>
           	
           </tr>

           <tr>
           	
           	<td colspan="3" style="text-align: center; font-weight: bold; font-size: 16px">Saldo</td>
           	<td colspan="2" align="center"><?php echo number_format($saldo,0,",",".") ?></td>
           
           
           </tr>

               

  </tbody>
</table><br>

<?php 

    $sql2 = $koneksi->query("select * from tb_profile ");

    $data1 = $sql2->fetch_assoc();

 ?>

<?php $tgl=date('Y-m-d'); ?>
<table width="100%">
<tr>
  <td align="center"></td>
  <td align="center" width="200px">
   <?php echo $data1['kota']; ?>, <?php echo tglIndonesia2(date('d F Y', strtotime($tgl))) ?>
    <br/>Bendahara,<br/><br/><br/>
    <b><u><?php echo $data1['bendahara']; ?></u><br/>Hp/Wa <?php echo $data1['nip']; ?></b>
  </td>
</tr>
</table>


