
 <?php 

 		

 		$sql = $koneksi->query("select * from tb_profile ");

 		$data = $sql->fetch_assoc();

 		
 		

  ?>

 <div class="row">
        <!-- left column -->
        <div class="col-md-6">
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Setting  Profile </h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form method="POST" enctype="multipart/form-data">
              <div class="box-body">

                <div class="form-group">
                  <label for="exampleInputEmail1">Nama Instansi</label>
                  <input type="text" class="form-control"   name="nama_sekolah" value="<?php echo $data['nama_sekolah'] ?>">
                </div>

             <div class="form-group">
                    <label>Alamat  </label>
                    <textarea class="form-control" rows="3" name="alamat"> <?php echo $data['alamat']; ?></textarea>
              </div> 

               <div class="form-group">
                  <label for="exampleInputEmail1">Telpon</label>
                  <input type="text" class="form-control"   name="telpon" value="<?php echo $data['telpon'] ?>">
                </div>


                 <div class="form-group">
                  <label for="exampleInputEmail1">No Whatsapp</label>
                  <input type="text" class="form-control"   name="no_wa" value="<?php echo $data['no_wa'] ?>">
                </div>

                 <div class="form-group">
                  <label for="exampleInputEmail1">Website</label>
                  <input type="text" class="form-control"   name="website" value="<?php echo $data['website'] ?>">
                </div>

                <div class="form-group">
                  <label for="exampleInputEmail1">Kota</label>
                  <input type="text" class="form-control"   name="kota" value="<?php echo $data['kota'] ?>">
                </div>

                 <div class="form-group">
                  <label for="exampleInputEmail1">Nama Bendahara</label>
                  <input type="text" class="form-control"   name="bendahara" value="<?php echo $data['bendahara'] ?>">
                </div>

                <div class="form-group">
                  <label for="exampleInputEmail1">Hp/Wa Bendahara</label>
                  <input type="text" class="form-control"   name="nip" value="<?php echo $data['nip'] ?>">
                </div>

               

                

                 <div class="form-group">
                  <label for="exampleInputPassword1">Logo</label>
                    <label><img src="images/<?php echo $data['foto'] ?>" widht="100" height="100" alt=""></label>
                </div>


                <div class="form-group">
                  <label for="exampleInputPassword1">Ganti Logo</label>
                  <input type="file"  name="foto">
                </div>

                 
                
             

              <div class="box-footer">
                <button type="submit" name="simpan" class="btn btn-primary">Simpan</button>
              </div>
            </form>
          </div>



          <?php 



          		if (isset($_POST['simpan'])) {
          			

          			$nama_sekolah = $_POST['nama_sekolah'];
          			$alamat = $_POST['alamat'];
          			$telpon = $_POST['telpon'];
                $no_wa = $_POST['no_wa'];

          			$website = $_POST['website'];

          			$kota = $_POST['kota'];

          			$bendahara = $_POST['bendahara'];

          			$nip = $_POST['nip'];
                $ktu = $_POST['ktu'];

                $nip_ktu = $_POST['nip_ktu'];


          			$foto = $_FILES['foto']['name'];
          		    $lokasi = $_FILES['foto']['tmp_name'];

          		   
          			
                  if (!empty($lokasi)) {
	
                    move_uploaded_file($lokasi, "images/".$foto);
          			$sql = $koneksi->query("update  tb_profile set nama_sekolah='$nama_sekolah', alamat='$alamat', telpon='$telpon', no_wa='$no_wa', website='$website', kota='$kota', bendahara='$bendahara', nip='$nip',  ktu='$ktu', nip_ktu='$nip_ktu',  foto='$foto' ");

          			if ($sql) {
          				?>

          					<script>
                            setTimeout(function() {
                                swal({
                                    title: 'Data Profile',
                                    text: 'Berhasil Diubah!',
                                    type: 'success'
                                }, function() {
                                    window.location = '?page=profile';
                                });
                            }, 300);
                        </script>


          				<?php
          			}




          		}else{
          			$sql = $koneksi->query("update  tb_profile set nama_sekolah='$nama_sekolah', alamat='$alamat', telpon='$telpon', website='$website', kota='$kota', no_wa='$no_wa', bendahara='$bendahara', nip='$nip', ktu='$ktu', nip_ktu='$nip_ktu' ");

          			if ($sql) {
          				?>

          					<script>
                            setTimeout(function() {
                                swal({
                                    title: 'Data Profile',
                                    text: 'Berhasil Diubah!',
                                    type: 'success'
                                }, function() {
                                    window.location = '?page=profile';
                                });
                            }, 300);
                        </script>


          				<?php
          			}
          		}
				
				}


           ?>